# FIX-05 — Missing Rate Limiters on `/api/check-mobile` and `/api/set-pin`

**Severity:** HIGH  
**File:** `backend/src/middleware/rateLimiter.js` and `backend/src/routes/chat.js`  
**Estimated Fix Time:** 10 minutes

---

## What Is the Issue?

Two endpoints have no rate limiting applied:

**`/api/check-mobile`** — no limiter  
An attacker can send unlimited automated requests to check whether any mobile number is registered. This enables rapid enumeration of the entire member database: send requests for every 10-digit number starting with 6-9 and collect which ones return `registered: true`.

**`/api/set-pin`** — no limiter  
Even after FIX-01 adds authentication to this endpoint, without a rate limiter an attacker who manages to obtain a valid session can attempt to brute-force their PIN change flow rapidly. More critically, without FIX-01 yet deployed, the absence of a rate limiter means bulk automated PIN overwrites across many mobile numbers are possible with no throttle.

Both endpoints currently process unlimited requests from any IP with no restriction.

---

## What Needs to Be Fixed?

Add rate limiters for both endpoints in `rateLimiter.js` and apply them in `chat.js`.

**Appropriate limits:**
- `/api/check-mobile` — 10 requests per 5 minutes per IP (checking your own number a few times is fine; mass enumeration is not)
- `/api/set-pin` — 5 requests per 15 minutes per IP

---

## How to Fix It

### Step 1 — Add limiters in `backend/src/middleware/rateLimiter.js`

```javascript
// Add these two alongside the existing limiters

const checkMobileLimiter = createRateLimiter(10, 5 * 60);  // 10 per 5 min
const setPinLimiter      = createRateLimiter(5, 15 * 60);  // 5 per 15 min

// Add to the exports:
module.exports = {
  adminLoginLimiter,
  sendOtpLimiter,
  verifyOtpLimiter,
  generateCardLimiter,
  validateEpicLimiter,
  publicVerifyLimiter,
  checkMobileLimiter,  // new
  setPinLimiter,       // new
};
```

### Step 2 — Apply limiters in `backend/src/routes/chat.js`

```javascript
const {
  ...,
  checkMobileLimiter,
  setPinLimiter,
} = require('../middleware/rateLimiter');

// Apply to check-mobile:
router.post('/check-mobile', checkMobileLimiter, async (req, res) => {

// Apply to set-pin:
router.post('/set-pin', setPinLimiter, async (req, res) => {
```

---

## Success After the Fix

- After 10 requests to `/api/check-mobile` within 5 minutes from the same IP, subsequent requests return `429 Too Many Requests`
- After 5 requests to `/api/set-pin` within 15 minutes from the same IP, subsequent requests return `429 Too Many Requests`
- Rate limit violations are automatically logged to Sentry (the existing `createRateLimiter` factory already does this)
- Legitimate users (checking their own number once or twice, setting their PIN once) are completely unaffected
- Automated enumeration and bulk attack attempts are blocked
