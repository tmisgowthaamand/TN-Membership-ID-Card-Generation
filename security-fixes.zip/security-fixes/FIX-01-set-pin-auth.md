# FIX-01 — `/api/set-pin` Has No Authentication

**Severity:** CRITICAL  
**File:** `backend/src/routes/chat.js`  
**Line:** 586  
**Estimated Fix Time:** 10 minutes

---

## What Is the Issue?

The `/api/set-pin` endpoint allows any person on the internet to set or overwrite a 4-digit PIN for **any** member's account — without proving they own that mobile number.

The endpoint accepts three fields: `mobile`, `epic_no`, and `pin`. It directly writes the hashed PIN into both the `generation_stats` and `generated_voters` collections for the given mobile number. There is no session check, no OTP check, and no rate limiter.

**Attack scenario:**
1. Attacker knows a member's mobile number (or guesses one)
2. Attacker POSTs to `/api/set-pin` with that mobile and a PIN they choose
3. The real member's PIN is now overwritten — they are locked out of their own account
4. Attacker can then use `/api/verify-pin` with the mobile + their chosen PIN to log in as that member

**Current vulnerable code:**
```javascript
// backend/src/routes/chat.js:586
router.post('/set-pin', async (req, res) => {
  // NO AUTH CHECK — anyone can call this
  const { valid: vm, value: mobile } = validateMobile((req.body.mobile || '').trim());
  ...
  await db.collection('generated_voters').updateMany(..., { $set: { secret_pin: hashed } });
```

---

## What Needs to Be Fixed?

1. Require a valid session (`req.session.verified_mobile`) before allowing PIN to be set
2. Assert that the mobile in the session matches the mobile in the request body — a user can only set their own PIN
3. Add a rate limiter to the endpoint

---

## How to Fix It

### Step 1 — Add session check at the top of the handler

```javascript
// backend/src/routes/chat.js:586
router.post('/set-pin', async (req, res) => {
  try {
    // AUTH CHECK — must have verified session
    if (!req.session?.verified_mobile) {
      return res.status(401).json({ success: false, message: 'Authentication required. Please verify your mobile first.' });
    }

    const { valid: vm, value: mobile } = validateMobile((req.body.mobile || '').trim());
    if (!vm) return res.status(400).json({ success: false, message: mobile });

    // OWNERSHIP CHECK — session mobile must match request mobile
    if (req.session.verified_mobile !== mobile) {
      return res.status(403).json({ success: false, message: 'You can only set your own PIN.' });
    }

    // ... rest of existing code unchanged ...
```

### Step 2 — Add rate limiter in `backend/src/middleware/rateLimiter.js`

```javascript
// Add alongside existing limiters
const setPinLimiter = createRateLimiter(5, 15 * 60); // 5 attempts per 15 minutes
module.exports = { ..., setPinLimiter };
```

### Step 3 — Apply limiter to the route

```javascript
const { setPinLimiter } = require('../middleware/rateLimiter');

router.post('/set-pin', setPinLimiter, async (req, res) => {
```

---

## Success After the Fix

- A request to `/api/set-pin` without a valid session returns `401 Unauthorized`
- A request with a valid session but a different mobile number in the body returns `403 Forbidden`
- Only the authenticated owner of the mobile number can set or update their PIN
- Brute force / automated PIN-overwrite attacks are blocked by rate limiting
- Existing legitimate flow (user verifies OTP → session set → sets PIN) continues to work without any change
