# FIX-01: `/api/set-pin` Has No Authentication

**Severity:** CRITICAL  
**Estimated Fix Time:** 10 minutes  
**File:** `backend/src/routes/chat.js` — Line 586

---

## What Is the Issue?

The `/api/set-pin` endpoint accepts a mobile number and a new PIN, then overwrites the stored PIN for that mobile — with **zero authentication**.

There is no session check, no OTP verification, nothing. Any person on the internet can send a POST request with any mobile number and overwrite that member's PIN.

**Current vulnerable code:**
```javascript
// chat.js line 586
router.post('/set-pin', async (req, res) => {
  const { mobile, pin, epic_no } = req.body;
  // jumps straight to hashing and writing to DB
  // no check that the caller owns this mobile number
```

**What an attacker can do right now:**
- POST `{ mobile: "9876543210", pin: "0000" }` → that member's PIN is now `0000` without their knowledge
- Lock out any member before they even set their own PIN for the first time
- Systematically overwrite all member PINs if they know the mobile numbers

---

## What Needs to Be Fixed?

The endpoint must verify that the person calling it has already proven ownership of the mobile number via OTP verification — i.e., they must have a valid session with `session.verified_mobile` matching the mobile in the request body.

---

## How to Fix It

**Step 1:** Add a session ownership check at the top of the `/set-pin` handler.

```javascript
// chat.js — replace the existing router.post('/set-pin', ...) with this:

router.post('/set-pin', async (req, res) => {
  try {
    const { valid: vm, value: mobile } = validateMobile((req.body.mobile || '').trim());
    if (!vm) return res.status(400).json({ success: false, message: mobile });

    // --- ADD THIS BLOCK ---
    // Ensure caller has a verified session AND it matches the mobile they're setting a PIN for
    if (!req.session?.verified_mobile) {
      return res.status(401).json({ success: false, message: 'Authentication required. Please verify your OTP first.' });
    }
    if (req.session.verified_mobile !== mobile) {
      return res.status(403).json({ success: false, message: 'You can only set a PIN for your own mobile number.' });
    }
    // --- END ADD ---

    const { valid: vp, value: pin } = validatePin((req.body.pin || '').trim());
    if (!vp) return res.status(400).json({ success: false, message: pin });

    // ... rest of the existing code unchanged
```

**Step 2:** Also add a rate limiter to this endpoint. Add it alongside the other limiters in `middleware/rateLimiter.js`:

```javascript
// In rateLimiter.js — export a new limiter:
const setPinLimiter = createRateLimiter(5, 15 * 60); // 5 attempts per 15 minutes
```

Then apply it in the route:

```javascript
router.post('/set-pin', setPinLimiter, async (req, res) => {
```

---

## Success Criteria

After the fix:

- A request to `/api/set-pin` without a session cookie returns `401 Authentication required`
- A request with a valid session but a different mobile (e.g., session is for `9876543210` but body has `9999999999`) returns `403 Forbidden`
- A request with a valid session where `session.verified_mobile === body.mobile` succeeds as before
- The member's own PIN-setting flow (after OTP verification) continues to work normally
- Repeated rapid attempts from one mobile get rate-limited after 5 tries in 15 minutes
