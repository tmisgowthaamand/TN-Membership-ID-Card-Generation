# FIX-05: Missing Rate Limiters on `/api/check-mobile` and `/api/set-pin`

**Severity:** HIGH  
**Estimated Fix Time:** 10 minutes  
**File:** `backend/src/middleware/rateLimiter.js` and `backend/src/routes/chat.js`

---

## What Is the Issue?

Two endpoints have no rate limiting applied:

- `/api/check-mobile` — Can be called unlimited times per second. Allows automated enumeration of whether any mobile number is registered in the system
- `/api/set-pin` — Can be called unlimited times per second. Even after FIX-01 adds authentication, rapid retries should be throttled

Every other sensitive endpoint in the system has a rate limiter. These two were missed.

**What an attacker can do right now:**

For `/api/check-mobile`:
- Write a script that checks 1000 mobile numbers per minute
- Build a map of which mobile numbers are registered members
- Use this list for targeted social engineering or as input to other attacks

For `/api/set-pin` (even after FIX-01 authentication is added):
- A user could hammer the endpoint to rapidly retry PIN setting
- No throttle means no protection against scripted abuse

---

## What Needs to Be Fixed?

Add rate limiters for both endpoints following the exact same pattern already used in the file.

---

## How to Fix It

**Step 1: Add two new limiters to `backend/src/middleware/rateLimiter.js`**

```javascript
// Add these alongside the existing limiters:

// /api/check-mobile — 5 checks per 5 minutes per IP
const chatCheckMobileLimiter = createRateLimiter(5, 5 * 60);

// /api/set-pin — 5 attempts per 15 minutes per IP
const chatSetPinLimiter = createRateLimiter(5, 15 * 60);

// Add both to the exports:
module.exports = {
  // ... existing exports ...
  chatCheckMobileLimiter,
  chatSetPinLimiter,
};
```

**Step 2: Import and apply in `backend/src/routes/chat.js`**

```javascript
// In the imports at the top of chat.js, add the new limiters:
const {
  // ... existing imports ...
  chatCheckMobileLimiter,
  chatSetPinLimiter,
} = require('../middleware/rateLimiter');

// Apply to /check-mobile route:
router.post('/check-mobile', chatCheckMobileLimiter, async (req, res) => {
  // ... existing handler ...
});

// Apply to /set-pin route:
router.post('/set-pin', chatSetPinLimiter, async (req, res) => {
  // ... existing handler ...
});
```

---

## Chosen Limits and Rationale

| Endpoint | Limit | Window | Rationale |
|----------|-------|--------|-----------|
| `/api/check-mobile` | 5 requests | 5 minutes | Legitimate users check once before registering. 5 allows for retries without enabling mass enumeration |
| `/api/set-pin` | 5 requests | 15 minutes | A user setting their PIN needs at most a couple of attempts. Matches the OTP/PIN verify limiter pattern already in use |

---

## Success Criteria

After the fix:

- The 6th call to `/api/check-mobile` within 5 minutes from the same IP returns `429 Too Many Requests` with the standard rate limit message
- The 6th call to `/api/set-pin` within 15 minutes from the same IP returns `429 Too Many Requests`
- A legitimate user calling each endpoint a normal number of times (1-3) is never blocked
- Rate limit violations are logged to Sentry automatically (already handled by the `createRateLimiter` factory)
