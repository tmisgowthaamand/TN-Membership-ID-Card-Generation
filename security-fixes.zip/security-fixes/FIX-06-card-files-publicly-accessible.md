# FIX-06: Generated Card PNG Files Are Permanently Publicly Accessible

**Severity:** MEDIUM  
**Estimated Fix Time:** 1 hour  
**Files:** `backend/src/routes/webhook.js` — Lines 486-497 and `backend/src/routes/upload.js` — Lines 602-613

---

## What Is the Issue?

When a membership card is generated, it is saved as a PNG file on the server's local filesystem and served as a static file:

```
File saved at:  /var/www/bjptn/dist/cards/{wtlCode}-{epicNo}.png
Accessible via: https://we-the-leader.onrender.com/cards/{wtlCode}-{epicNo}.png
```

**The filename is predictable.** It is constructed from two values:
- `wtlCode` — format `BJP-{8 hex chars}`, which can be guessed or observed
- `epicNo` — the voter's EPIC number, which is printed on their physical voter ID card and is semi-public

For the **WhatsApp flow**, card files are deleted after 60 seconds — this is handled correctly. For the **web flow** (via `upload.js`), the card file is written but **never deleted**. The URL is stored permanently in `generated_voters.card_url` pointing to this static file.

**What anyone can do right now:**
- Knowing a member's EPIC number, construct the card filename
- Download their BJP membership card without any authentication
- Membership cards contain the member's name, photo, EPIC number, and WTL code

---

## What Needs to Be Fixed?

Two options — choose one:

**Option A (Recommended):** Delete the card file after sending the response to the user, just like the WhatsApp flow already does (60-second delayed delete). Store the card in Backblaze B2 instead and use a presigned URL for download — consistent with how member photos are already handled.

**Option B (Quick fix):** Delete the local file immediately after the HTTP response is sent (stream the file to response, then delete). The user still downloads their card, but the file doesn't persist on disk.

Option A is recommended because it's consistent with the existing B2 architecture. Option B is faster to implement.

---

## How to Fix It — Option B (Quick Fix)

In `backend/src/routes/upload.js`, after writing the card file and sending the response, schedule an immediate deletion:

```javascript
// Current code (upload.js ~line 602):
const tempCardsDir = isProd
  ? '/var/www/bjptn/dist/cards'
  : path.join(__dirname, '../../../frontend/dist/cards');

const fileName = `${wtlCode}-${epicNo}.png`;
const filePath = path.join(tempCardsDir, fileName);
fs.writeFileSync(filePath, frontBuffer);

const frontUrl = `${config.baseUrl}/cards/${fileName}`;

// ADD: Schedule deletion after 120 seconds (gives user time to download)
setTimeout(() => {
  fs.unlink(filePath, (err) => {
    if (err && err.code !== 'ENOENT') {
      console.error('[Card] Failed to delete temp card file:', err.message);
    }
  });
}, 120 * 1000);
```

Also update `generated_voters.card_url` to not store the static file URL as a permanent reference — either store `null`/empty, or upload to B2 and store the B2 URL.

---

## How to Fix It — Option A (Recommended: Upload to B2)

Use the existing `backblazeService.js` to upload the card PNG to B2 (same as photos), then store the B2 path in the database. Generate a presigned URL on demand when the user requests their card.

```javascript
// In upload.js, after generating frontBuffer:

// Upload card to B2
const cardB2Key = `member_cards/${epicNo}_${mobile}.png`;
await uploadToB2(cardB2Key, frontBuffer, 'image/png');

// Store B2 key in DB (not a static file URL)
await db.collection('generated_voters').updateOne(
  { MOBILE_NO: mobile },
  { $set: { card_b2_key: cardB2Key } }
);

// Generate presigned URL for this response only (7 days)
const cardUrl = await getPresignedUrl(cardB2Key);

// No local file written — no static file to worry about
```

Add a corresponding endpoint to regenerate the presigned URL when the user wants to view their card again (same pattern as photos).

---

## Success Criteria

After the fix (Option B):

- The card PNG file is deleted from the server filesystem within 120 seconds of generation
- Attempting to access `{baseUrl}/cards/{wtlCode}-{epicNo}.png` after 120 seconds returns `404 Not Found`
- The user's card download works normally — they receive the file before deletion
- No card files accumulate in `/var/www/bjptn/dist/cards/`

After the fix (Option A):

- No card PNG files are ever written to the local filesystem
- Card images are stored in Backblaze B2 under `member_cards/`
- Accessing a card requires a presigned URL with a 7-day expiry — unauthenticated direct access is impossible
- Consistent with how member photos are already handled
