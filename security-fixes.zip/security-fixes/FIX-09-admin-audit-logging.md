# FIX-09: No Audit Trail for Admin Actions

**Severity:** HIGH  
**Estimated Fix Time:** 3 hours  
**File:** `backend/src/routes/admin.js` (all POST routes)

---

## What Is the Issue?

Admins can perform the following irreversible state-changing actions through the admin panel:

- Confirm a volunteer request
- Reject a volunteer request
- Confirm a booth agent request
- Reject a booth agent request
- View any member's complete details

None of these actions are logged anywhere. There is no record of:
- Who did it (admin username)
- When it happened (timestamp)
- What was changed (which WTL code, which status)
- What the previous state was

**Why this matters:**

- If a volunteer claims they were wrongly rejected, there is no way to investigate
- If an admin account is compromised, there is no way to see what the attacker did
- If data is changed incorrectly, there is no way to audit what happened or roll back
- There is no accountability for admin decisions

Currently, only **failed login attempts** are sent to Sentry. Successful admin actions — which actually change member data — are not tracked at all.

---

## What Needs to Be Fixed?

Create an `admin_audit_log` MongoDB collection in DB2 (`wetheleaders`) and write an entry to it every time an admin performs a state-changing action.

---

## How to Fix It

**Step 1: Create an audit log utility in `backend/src/utils/auditLog.js`**

```javascript
'use strict';

const { getDb } = require('../db');

/**
 * Write an admin action to the audit log.
 *
 * @param {object} params
 * @param {string} params.adminUsername  - Who performed the action
 * @param {string} params.action         - What was done (e.g., 'volunteer_confirmed')
 * @param {string} params.targetWtlCode  - Which member was affected
 * @param {string} params.targetMobile   - Member's mobile (masked)
 * @param {object} params.previousState  - State before the change
 * @param {object} params.newState       - State after the change
 * @param {string} params.ip             - Admin's IP address
 * @param {object} params.meta           - Any additional context
 */
async function writeAuditLog({
  adminUsername,
  action,
  targetWtlCode = null,
  targetMobile = null,
  previousState = null,
  newState = null,
  ip = null,
  meta = {},
}) {
  try {
    const db = getDb();
    await db.collection('admin_audit_log').insertOne({
      timestamp:      new Date(),
      adminUsername,
      action,
      targetWtlCode,
      targetMobile:   targetMobile ? `****${String(targetMobile).slice(-4)}` : null,
      previousState,
      newState,
      ip,
      meta,
    });
  } catch (err) {
    // Audit log failure must never break the main operation
    console.error('[AuditLog] Failed to write audit entry:', err.message);
  }
}

module.exports = { writeAuditLog };
```

**Step 2: Add audit log entries to each admin action in `backend/src/routes/admin.js`**

```javascript
const { writeAuditLog } = require('../utils/auditLog');

// Example: Volunteer confirmation
router.post('/volunteer-requests/:wtlCode/confirm', requireAdminAuth, async (req, res) => {
  try {
    const { wtlCode } = req.params;
    const db = getDb();

    const request = await db.collection('volunteer_requests').findOne({ wtl_code: wtlCode });
    const previousStatus = request?.status;

    await db.collection('volunteer_requests').updateOne(
      { wtl_code: wtlCode },
      { $set: { status: 'confirmed', confirmed_at: new Date() } }
    );

    // --- ADD AUDIT LOG ---
    await writeAuditLog({
      adminUsername:  req.session.adminUsername,
      action:         'volunteer_confirmed',
      targetWtlCode:  wtlCode,
      targetMobile:   request?.mobile,
      previousState:  { status: previousStatus },
      newState:       { status: 'confirmed' },
      ip:             req.ip,
    });
    // --- END AUDIT LOG ---

    return res.json({ success: true });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});
```

Apply the same pattern to all these routes:

| Route | Action Name |
|-------|-------------|
| `POST /volunteer-requests/:wtlCode/confirm` | `volunteer_confirmed` |
| `POST /volunteer-requests/:wtlCode/reject` | `volunteer_rejected` |
| `POST /booth-agent-requests/:wtlCode/confirm` | `booth_agent_confirmed` |
| `POST /booth-agent-requests/:wtlCode/reject` | `booth_agent_rejected` |

**Step 3: Add a MongoDB TTL index to auto-expire old audit logs (optional but recommended)**

```javascript
// Run once in MongoDB shell or migration script:
db.admin_audit_log.createIndex({ timestamp: 1 }, { expireAfterSeconds: 365 * 24 * 60 * 60 });
// Keeps audit logs for 1 year then auto-deletes
```

**Step 4: Expose audit log to admin panel (optional but useful)**

```javascript
// New admin endpoint to view audit log:
router.get('/audit-log', requireAdminAuth, async (req, res) => {
  const db = getDb();
  const limit = Math.min(parseInt(req.query.limit) || 50, 200);
  const logs = await db.collection('admin_audit_log')
    .find({})
    .sort({ timestamp: -1 })
    .limit(limit)
    .toArray();
  return res.json({ success: true, logs });
});
```

---

## Success Criteria

After the fix:

- Confirming a volunteer creates a document in `admin_audit_log` with `action: 'volunteer_confirmed'`, the admin's username, timestamp, WTL code, and masked mobile
- Rejecting a booth agent creates a document with `action: 'booth_agent_rejected'`
- If the audit log write fails (DB error), the main confirm/reject operation still completes — audit failure is non-fatal
- Admin mobile numbers in the log are masked as `****1234` — the last 4 digits only
- `db.admin_audit_log.find({}).count()` grows by 1 for each admin action taken
- The audit log endpoint (`GET /admin/api/audit-log`) returns a list of recent admin actions viewable in the admin panel
