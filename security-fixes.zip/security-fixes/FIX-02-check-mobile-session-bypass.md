# FIX-02: `/api/check-mobile` Creates Session Without OTP

**Severity:** CRITICAL  
**Estimated Fix Time:** 10 minutes  
**File:** `backend/src/routes/chat.js` — Lines 219-220

---

## What Is the Issue?

The `/api/check-mobile` endpoint is supposed to simply check whether a mobile number is already registered in the system. However, it also **creates a full authenticated session** for whoever calls it — without requiring any OTP or PIN.

**Current vulnerable code:**
```javascript
// chat.js lines 219-220
req.session.verified_mobile = mobile;
req.session.cookie.maxAge = 86400 * 1000;
```

These two lines run immediately when a mobile number is POSTed to this endpoint. No OTP. No PIN. No proof of ownership.

**What an attacker can do right now:**
- POST `{ mobile: "9876543210" }` to `/api/check-mobile`
- Receive a valid session cookie in the response
- Use that session cookie to access `/api/request-status/:wtlCode` (which requires a session)
- Access that session's fallback in card generation: `req.session.verified_mobile || req.body.mobile`

This completely bypasses the OTP verification flow that is supposed to be the only way to get a session.

---

## What Needs to Be Fixed?

Remove the session-setting lines from `/api/check-mobile`. The endpoint's only job is to return whether the mobile is registered and whether they have a card. It should not touch the session at all.

---

## How to Fix It

Find the `/api/check-mobile` handler in `chat.js` and **delete the two session lines**:

```javascript
// REMOVE these two lines from the /api/check-mobile handler:
req.session.verified_mobile = mobile;        // ← DELETE THIS
req.session.cookie.maxAge = 86400 * 1000;    // ← DELETE THIS
```

The endpoint should only read and return data. A valid implementation looks like this:

```javascript
router.post('/check-mobile', async (req, res) => {
  try {
    const { valid: vm, value: mobile } = validateMobile((req.body.mobile || '').trim());
    if (!vm) return res.status(400).json({ success: false, message: mobile });

    const db = getDb();
    const existing = await db.collection('generated_voters').findOne({
      $or: [{ MOBILE_NO: mobile }, { mobile }]
    });

    // DO NOT set session here — just return the status
    return res.json({
      success: true,
      registered: !!existing,
      has_card: !!(existing?.card_url),
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});
```

A session must only be created after the user completes OTP verification via `/api/verify-otp` or PIN verification via `/api/verify-pin`.

---

## Success Criteria

After the fix:

- A POST to `/api/check-mobile` with a valid mobile returns `{ registered: true/false, has_card: true/false }` as before
- The response does **not** include a `Set-Cookie` header (no session is created)
- After calling `/api/check-mobile`, a subsequent call to `/api/request-status/:wtlCode` using the same connection returns `401 Authentication required` (no session was established)
- The normal OTP → session flow is completely unaffected
