# FIX-07: Puppeteer — Missing Screenshot Timeout and No Concurrency Limit

**Severity:** MEDIUM  
**Estimated Fix Time:** 1.5 hours  
**File:** `backend/src/services/cardGenerator.js`

---

## What Is the Issue?

There are two related problems in the Puppeteer card generation service:

### Problem A — No Screenshot Timeout

The `page.screenshot()` call has no timeout:

```javascript
// cardGenerator.js line ~101
const screenshotBuffer = await cardHandle.screenshot({ type: 'png' });
```

If this call hangs — due to a corrupted photo, a memory pressure edge case, or a Chromium rendering bug — the `await` never resolves. The `finally { await page.close() }` block only runs after the screenshot resolves, so the page stays open forever.

**Result:** A zombie page accumulates in memory. Under sustained traffic with occasional hangs, memory climbs without bound until the process crashes.

### Problem B — No Concurrency Limit

There is no cap on how many card generations can run simultaneously. Each open Puppeteer page consumes approximately 50-100MB of RAM.

```
50 concurrent requests × 75MB per page = ~3.75GB RAM consumed by Puppeteer alone
100 concurrent requests × 75MB per page = ~7.5GB RAM — server is at its limit
150 concurrent requests = server crashes
```

The per-mobile rate limiter (15 cards per 10 minutes) only limits a single user. It does nothing to cap the total number of concurrent pages across all users simultaneously.

---

## What Needs to Be Fixed?

1. Wrap `page.screenshot()` in a timeout so hung screenshots are killed and the page is closed
2. Add a concurrency semaphore so a maximum of N card generations run simultaneously at any time

---

## How to Fix It

### Fix A — Screenshot Timeout

Wrap the entire `generateCard` function in a `Promise.race` with a timeout:

```javascript
// cardGenerator.js — wrap the export function

const CARD_GENERATION_TIMEOUT_MS = 30000; // 30 seconds

async function generateCardWithTimeout(voter, photoBuffer = null) {
  const timeoutPromise = new Promise((_, reject) =>
    setTimeout(
      () => reject(new Error('Card generation timed out after 30 seconds')),
      CARD_GENERATION_TIMEOUT_MS
    )
  );
  return Promise.race([generateCard(voter, photoBuffer), timeoutPromise]);
}

module.exports = { generateCard: generateCardWithTimeout };
```

The `finally { await page.close() }` inside `generateCard` still runs because the timeout rejection causes the outer `Promise.race` to reject, but the internal `generateCard` promise continues until it either resolves or the Node process reaps it. To guarantee page closure on timeout, restructure the internal function:

```javascript
async function generateCard(voter, photoBuffer = null) {
  const browser = await getBrowser();
  const page = await browser.newPage();
  
  let screenshotTimeout;
  
  try {
    await page.setViewport({ width: 1600, height: 1100, deviceScaleFactor: 2 });
    await page.setContent(html, { waitUntil: 'domcontentloaded', timeout: 15000 });
    await page.evaluate(/* inject data */);

    // Screenshot with explicit timeout via Promise.race
    const screenshotPromise = cardHandle.screenshot({ type: 'png' });
    const timeoutPromise = new Promise((_, reject) => {
      screenshotTimeout = setTimeout(
        () => reject(new Error('Screenshot timed out')),
        15000
      );
    });

    const screenshotBuffer = await Promise.race([screenshotPromise, timeoutPromise]);
    clearTimeout(screenshotTimeout);
    return screenshotBuffer;

  } finally {
    clearTimeout(screenshotTimeout); // clean up even if screenshot threw
    await page.close().catch(() => {}); // close page no matter what
  }
}
```

### Fix B — Concurrency Semaphore

Add a simple semaphore before the browser/page creation. A semaphore limits how many async operations can run simultaneously.

```javascript
// cardGenerator.js — add at the top of the file:

const MAX_CONCURRENT_GENERATIONS = 8; // safe limit for 16GB server
let activeGenerations = 0;
const waitQueue = [];

function acquireSemaphore() {
  return new Promise((resolve) => {
    if (activeGenerations < MAX_CONCURRENT_GENERATIONS) {
      activeGenerations++;
      resolve();
    } else {
      waitQueue.push(resolve);
    }
  });
}

function releaseSemaphore() {
  if (waitQueue.length > 0) {
    const next = waitQueue.shift();
    next(); // hand the slot to the next waiter
  } else {
    activeGenerations--;
  }
}

// Wrap generateCard to use the semaphore:
async function generateCard(voter, photoBuffer = null) {
  await acquireSemaphore();
  try {
    return await _generateCard(voter, photoBuffer); // rename original to _generateCard
  } finally {
    releaseSemaphore();
  }
}
```

**Chosen limit of 8 concurrent generations:**
- 8 pages × ~75MB = ~600MB RAM used by Puppeteer at peak
- Leaves ample headroom on a 16GB server
- Can be tuned up (to 12-15) or down (to 5) based on observed memory usage

---

## Success Criteria

After Fix A:

- A simulated hung screenshot (e.g., freeze the page with `page.evaluate(() => { while(true){} })`) causes `generateCard` to throw `Card generation timed out` within 30 seconds
- The page is closed after the timeout — `browser.pages().length` returns to baseline after a hung request
- No zombie pages accumulate under any error condition

After Fix B:

- When 20 concurrent card generation requests arrive, only 8 begin processing immediately
- The remaining 12 wait in queue and begin as slots free up — no requests are rejected, they just wait
- Memory usage under 20 concurrent requests stays under 2GB for Puppeteer
- `activeGenerations` never exceeds `MAX_CONCURRENT_GENERATIONS` (can verify by logging)
