# FIX-03 — Admin Password Stored and Compared in Plaintext

**Severity:** CRITICAL  
**File:** `backend/src/routes/admin.js`  
**Line:** 53–54  
**Estimated Fix Time:** 30 minutes

---

## What Is the Issue?

The admin login compares the submitted password directly against the plaintext value stored in the `.env` file:

```javascript
// backend/src/routes/admin.js:53-54
if (username === config.admin.username && password === config.admin.password) {
  req.session.adminLoggedIn = true;
```

The `.env` file currently contains:
```
ADMIN_USERNAME=BJP
ADMIN_PASSWORD=BJP@2026
```

If the `.env` file is ever exposed — through an accidental git commit, a hosting panel breach, a misconfigured file server, or a server compromise — the admin password is immediately usable with zero additional effort. There is no hashing, no salting, no work factor.

Additionally, `bcryptjs` is listed in `package.json` but is never imported or used anywhere in the codebase — it was clearly intended for this exact purpose and was never wired up.

---

## What Needs to Be Fixed?

1. Hash the admin password using bcrypt and store the **hash** in `.env` instead of the plaintext password
2. Update the login handler to compare using `bcrypt.compare()` instead of `===`
3. The plaintext password variable (`ADMIN_PASSWORD`) should be replaced with `ADMIN_PASSWORD_HASH`

---

## How to Fix It

### Step 1 — Generate the bcrypt hash (run this once, in terminal)

```bash
cd backend
node -e "const bcrypt = require('bcryptjs'); bcrypt.hash('BJP@2026', 12).then(h => console.log(h))"
```

This prints a hash like:
```
$2a$12$XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
```

### Step 2 — Update `.env`

```env
# Remove this:
ADMIN_PASSWORD=BJP@2026

# Add this (paste the hash from Step 1):
ADMIN_PASSWORD_HASH=$2a$12$XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
```

### Step 3 — Update `backend/src/config.js`

```javascript
// Change:
admin: {
  username: process.env.ADMIN_USERNAME,
  password: process.env.ADMIN_PASSWORD,
}

// To:
admin: {
  username: process.env.ADMIN_USERNAME,
  passwordHash: process.env.ADMIN_PASSWORD_HASH,
}
```

Also update the startup validation:
```javascript
// Change:
if (!process.env.ADMIN_USERNAME || !process.env.ADMIN_PASSWORD) {
  throw new Error('ADMIN_USERNAME and ADMIN_PASSWORD must be set in .env');
}

// To:
if (!process.env.ADMIN_USERNAME || !process.env.ADMIN_PASSWORD_HASH) {
  throw new Error('ADMIN_USERNAME and ADMIN_PASSWORD_HASH must be set in .env');
}
```

### Step 4 — Update `backend/src/routes/admin.js`

```javascript
const bcrypt = require('bcryptjs'); // add at top of file

// Change the login handler from:
if (username === config.admin.username && password === config.admin.password) {
  req.session.adminLoggedIn = true;
  req.session.adminUsername = username;
}

// To:
if (username === config.admin.username) {
  const passwordMatch = await bcrypt.compare(password, config.admin.passwordHash);
  if (passwordMatch) {
    req.session.adminLoggedIn = true;
    req.session.adminUsername = username;
  }
}
```

> Note: Make the route handler `async` if it is not already.

---

## Success After the Fix

- The `.env` file contains only a bcrypt hash — even if leaked, the hash cannot be reversed to the original password without a brute-force attack that would take years at 12 rounds
- Admin login continues to work correctly — `bcrypt.compare()` validates the correct password against the stored hash
- The `bcryptjs` package (already installed, previously unused) is now properly wired up
- The timing of the comparison is inherently resistant to timing attacks because bcrypt is constant-time by design
- To change the admin password in future: generate a new hash, update `.env`, restart — no code changes needed
