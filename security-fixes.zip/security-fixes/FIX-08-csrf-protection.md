# FIX-08: CSRF Protection Missing on Admin Routes

**Severity:** MEDIUM  
**Estimated Fix Time:** 1-2 hours  
**File:** `backend/src/index.js` and `backend/src/routes/admin.js`

---

## What Is the Issue?

CSRF (Cross-Site Request Forgery) is an attack where a malicious website tricks an already-logged-in user's browser into making requests to your backend — and the browser automatically sends the session cookie along.

The session cookie is configured with `sameSite: 'none'` because the frontend (Vercel) and backend (Render/DigitalOcean) are on different domains. `sameSite: 'none'` means the browser will send the cookie on **any** cross-site request, not just same-origin ones. CORS blocks cross-origin reads, but it does **not** block the request from being sent and processed.

**CSRF attack scenario:**

1. Admin is logged in to the admin panel — `wtl.session` cookie is active in their browser
2. Admin visits a malicious website (e.g., a link in an email)
3. Malicious page contains:
   ```html
   <form action="https://we-the-leader.onrender.com/admin/api/volunteer-requests/BJP-AAAA1111/confirm" method="POST">
   </form>
   <script>document.forms[0].submit()</script>
   ```
4. Browser sends the POST with the admin's session cookie automatically
5. Backend processes the request as a legitimate admin action — volunteer is confirmed without admin knowing

Any state-changing admin operation is vulnerable: confirming/rejecting volunteers, confirming/rejecting booth agents.

---

## What Needs to Be Fixed?

Add CSRF token protection to all admin state-changing routes (POST endpoints under `/admin/api/`). The approach is:

- When the admin loads the dashboard, the backend sends a CSRF token
- Every subsequent POST from the frontend must include this token in a header
- The backend validates the token before processing the request
- A cross-site attacker's page cannot read the CSRF token (blocked by CORS/same-origin policy) and therefore cannot forge valid requests

---

## How to Fix It

**Step 1: Install `csurf`**

```bash
cd backend
npm install csurf
```

**Step 2: Add CSRF middleware in `backend/src/index.js`**

Apply CSRF protection only to admin routes (not to WhatsApp webhooks or public API):

```javascript
const csrf = require('csurf');

// After session middleware, before routes:
const csrfProtection = csrf({
  cookie: false,         // use session-based CSRF (more secure)
  ignoreMethods: ['GET', 'HEAD', 'OPTIONS'],
});

// Apply only to admin routes
app.use('/admin/api', csrfProtection);

// Endpoint for frontend to fetch the CSRF token
app.get('/admin/api/csrf-token', csrfProtection, (req, res) => {
  res.json({ csrfToken: req.csrfToken() });
});

// CSRF error handler
app.use((err, req, res, next) => {
  if (err.code === 'EBADCSRFTOKEN') {
    return res.status(403).json({ success: false, message: 'Invalid or missing CSRF token.' });
  }
  next(err);
});
```

**Step 3: Update the admin frontend to fetch and send the token**

In the admin React frontend, fetch the CSRF token once after login and include it in all subsequent POST requests:

```javascript
// In admin API utility / axios setup:

let csrfToken = null;

async function fetchCsrfToken() {
  const res = await fetch('/admin/api/csrf-token', { credentials: 'include' });
  const data = await res.json();
  csrfToken = data.csrfToken;
}

// Call fetchCsrfToken() after successful admin login

// Include in all admin POST requests:
const response = await fetch('/admin/api/volunteer-requests/BJP-AAAA1111/confirm', {
  method: 'POST',
  credentials: 'include',
  headers: {
    'Content-Type': 'application/json',
    'X-CSRF-Token': csrfToken,   // ← add this header
  },
});
```

If using axios, set it as a default header after login:
```javascript
axios.defaults.headers.common['X-CSRF-Token'] = csrfToken;
```

**Routes NOT protected by CSRF (intentionally excluded):**
- `POST /api/webhook` — verified by Meta HMAC signature instead
- `POST /api/webhook/flow` — verified by RSA-AES encryption
- All public `GET` endpoints — read-only, no state change

---

## Success Criteria

After the fix:

- Admin login, view pages (GET) work as before — no CSRF token needed for GET requests
- Admin POST actions (confirm volunteer, reject booth agent, etc.) succeed when the frontend sends the `X-CSRF-Token` header
- A POST to any `/admin/api/` endpoint **without** the `X-CSRF-Token` header returns `403 Invalid or missing CSRF token`
- A CSRF attack from a third-party website fails with `403` — the attacker's page cannot read the token due to same-origin policy
- WhatsApp webhook endpoints are completely unaffected — they are not under `/admin/api/`
