# FIX-04: IDOR on `/api/request-status/:wtlCode`

**Severity:** HIGH  
**Estimated Fix Time:** 15 minutes  
**File:** `backend/src/routes/chat.js` — Lines 244-269

---

## What Is the Issue?

IDOR stands for Insecure Direct Object Reference. The `/api/request-status/:wtlCode` endpoint checks that the caller has *a* session, but does not check that the session belongs to the owner of that WTL code.

**Current code logic:**
```javascript
// chat.js lines 244-269
router.get('/request-status/:wtlCode', async (req, res) => {
  if (!req.session?.verified_mobile) {
    return res.status(401).json({ ... }); // checks session exists ✅
  }

  const { wtlCode } = req.params;
  const result = await db.collection('generated_voters').findOne({ wtl_code: wtlCode });
  // returns result directly — NO check that result.MOBILE_NO === session.verified_mobile ❌
  return res.json(result);
});
```

**What an attacker can do right now:**

1. Complete OTP verification for their own mobile — get a valid session
2. Call `/api/request-status/BJP-XXXXXXXX` with any WTL code
3. Receive the volunteer/booth agent request status of whoever owns that WTL code
4. Enumerate WTL codes systematically to harvest all member statuses

WTL codes follow the pattern `BJP-{8 hex chars}`. In a member base of a few thousand, brute-forcing to find valid codes is feasible.

---

## What Needs to Be Fixed?

After fetching the record by WTL code, add a check that the mobile number on that record matches the mobile number in the session. If it does not match, return `403 Forbidden` — not `404`, as returning `404` would reveal that the code belongs to someone else.

---

## How to Fix It

```javascript
router.get('/request-status/:wtlCode', async (req, res) => {
  try {
    if (!req.session?.verified_mobile) {
      return res.status(401).json({ success: false, message: 'Authentication required.' });
    }

    const { wtlCode } = req.params;
    const db = getDb();

    const result = await db.collection('generated_voters').findOne({ wtl_code: wtlCode });

    // --- ADD THIS OWNERSHIP CHECK ---
    if (!result) {
      return res.status(404).json({ success: false, message: 'Not found.' });
    }

    const recordMobile = String(result.MOBILE_NO || result.mobile || '').replace(/^91/, '');
    const sessionMobile = String(req.session.verified_mobile || '').replace(/^91/, '');

    if (recordMobile !== sessionMobile) {
      return res.status(403).json({ success: false, message: 'Access denied.' });
    }
    // --- END OWNERSHIP CHECK ---

    return res.json({ success: true, data: result });

  } catch (err) {
    return res.status(500).json({ success: false, message: 'Server error.' });
  }
});
```

**Note on mobile number format:** The voter DB stores mobile numbers in different formats (`9876543210`, `919876543210`, number type vs string type). Strip the `91` prefix before comparing to handle all variants safely.

---

## Success Criteria

After the fix:

- User A (mobile `9876543210`, WTL `BJP-AAAA1111`) calls `/api/request-status/BJP-AAAA1111` — receives `200 OK` with their own data
- User A calls `/api/request-status/BJP-BBBB2222` (owned by User B) — receives `403 Access denied`
- An unauthenticated caller gets `401 Authentication required` as before
- A WTL code that does not exist returns `404 Not found`
- User B's volunteer/booth agent status is never visible to User A under any circumstance
