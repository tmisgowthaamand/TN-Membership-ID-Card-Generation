# FIX-02 — `/api/check-mobile` Sets Session Without OTP

**Severity:** CRITICAL  
**File:** `backend/src/routes/chat.js`  
**Line:** 219–220  
**Estimated Fix Time:** 10 minutes

---

## What Is the Issue?

The `/api/check-mobile` endpoint is intended to check whether a mobile number is already registered in the system. However, it also sets `req.session.verified_mobile` — meaning it grants an authenticated session to **anyone who calls it with any mobile number**, without requiring OTP verification or a PIN.

There is zero proof of mobile ownership. Any attacker can:
1. POST any mobile number to `/api/check-mobile`
2. Receive a valid authenticated session cookie
3. Use that session to access authenticated endpoints such as `/api/request-status/:wtlCode`
4. The mobile fallback in card generation also reads `req.session.verified_mobile || req.body.mobile` — this session influences card generation logic

**Current vulnerable code:**
```javascript
// backend/src/routes/chat.js:219-220
req.session.verified_mobile = mobile;      // ← session set with NO verification
req.session.cookie.maxAge = 86400 * 1000;
```

---

## What Needs to Be Fixed?

The `/api/check-mobile` endpoint should only check and return whether the mobile number exists in the system. It must not create or modify any session. Session establishment must only happen through:
- `/api/verify-otp` (OTP-based login)
- `/api/verify-pin` (PIN-based login)

---

## How to Fix It

### Remove the two session-setting lines

Find this block in `backend/src/routes/chat.js` around line 219:

```javascript
// REMOVE THESE TWO LINES:
req.session.verified_mobile = mobile;
req.session.cookie.maxAge = 86400 * 1000;
```

The endpoint should only return whether the mobile is registered. The response logic below those lines can stay as-is. Example of what the handler should look like after removal:

```javascript
router.post('/check-mobile', async (req, res) => {
  try {
    const { valid: vm, value: mobile } = validateMobile((req.body.mobile || '').trim());
    if (!vm) return res.status(400).json({ success: false, message: mobile });

    // DO NOT set session here — just check and return status
    const db = getDb();
    const existing = await db.collection('generated_voters').findOne({
      $or: [{ MOBILE_NO: mobile }, { mobile }]
    });

    return res.json({
      success: true,
      registered: !!existing,
      has_pin: !!(existing?.secret_pin),
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});
```

---

## Success After the Fix

- Calling `/api/check-mobile` with any mobile number no longer creates a session
- The response still correctly tells the frontend whether the mobile is registered (so the UI can route to OTP vs PIN login) — no UX change
- An attacker cannot obtain an authenticated session without completing OTP or PIN verification
- The auth bypass is eliminated — all downstream session-protected endpoints (`/api/request-status`, card generation) can no longer be accessed via this shortcut
