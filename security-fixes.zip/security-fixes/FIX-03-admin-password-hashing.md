# FIX-03: Admin Password Stored and Compared in Plaintext

**Severity:** CRITICAL  
**Estimated Fix Time:** 30 minutes  
**File:** `backend/src/routes/admin.js` — Lines 53-54

---

## What Is the Issue?

The admin login endpoint compares the submitted password directly against a plaintext value stored in the `.env` file. There is no hashing.

**Current `.env`:**
```
ADMIN_USERNAME=BJP
ADMIN_PASSWORD=BJP@2026
```

**Current vulnerable code:**
```javascript
// admin.js lines 53-54
if (username === config.admin.username && password === config.admin.password) {
  req.session.adminLoggedIn = true;
```

**What this means:**

- If the `.env` file is ever exposed — via a git accident, a hosting panel breach, a misconfigured server showing directory listings, or a server compromise — the admin password is immediately readable in plaintext
- There is no defense in depth. One leak = full admin access
- `bcryptjs` is already installed in `package.json` but is never imported or used anywhere in the codebase — it was clearly intended for exactly this purpose

---

## What Needs to Be Fixed?

1. Generate a bcrypt hash of the admin password
2. Store the **hash** (not the plaintext password) in `.env`
3. Update the login handler to use `bcrypt.compare()` instead of `===`

---

## How to Fix It

**Step 1: Generate the bcrypt hash**

Run this once in the terminal to get the hash of your chosen admin password:

```bash
cd backend
node -e "const bcrypt = require('bcryptjs'); bcrypt.hash('YOUR_ADMIN_PASSWORD_HERE', 12).then(h => console.log(h))"
```

Copy the output (it will look like `$2a$12$...`).

**Step 2: Update `.env`**

```env
# Remove the plaintext password:
# ADMIN_PASSWORD=BJP@2026     ← DELETE THIS LINE

# Add the hash instead:
ADMIN_PASSWORD_HASH=$2a$12$...your-hash-output-here...
```

**Step 3: Update `backend/src/config.js`**

```javascript
// Replace:
admin: {
  username: process.env.ADMIN_USERNAME,
  password: process.env.ADMIN_PASSWORD,
}

// With:
admin: {
  username: process.env.ADMIN_USERNAME,
  passwordHash: process.env.ADMIN_PASSWORD_HASH,
}
```

Also update the startup validation:
```javascript
// Replace:
if (!process.env.ADMIN_USERNAME || !process.env.ADMIN_PASSWORD) {
  throw new Error('ADMIN_USERNAME and ADMIN_PASSWORD must be set in .env');
}

// With:
if (!process.env.ADMIN_USERNAME || !process.env.ADMIN_PASSWORD_HASH) {
  throw new Error('ADMIN_USERNAME and ADMIN_PASSWORD_HASH must be set in .env');
}
```

**Step 4: Update `backend/src/routes/admin.js`**

```javascript
// Add at the top of the file:
const bcrypt = require('bcryptjs');

// Replace the plaintext comparison (lines 53-54):
// OLD:
if (username === config.admin.username && password === config.admin.password) {

// NEW:
const passwordValid = await bcrypt.compare(password, config.admin.passwordHash);
if (username === config.admin.username && passwordValid) {
```

Note: make the handler `async` if it isn't already, since `bcrypt.compare()` returns a Promise.

---

## Success Criteria

After the fix:

- Logging in with the correct admin password succeeds as before
- Logging in with a wrong password returns `401 Unauthorized` as before
- The `.env` file no longer contains any human-readable password — only a bcrypt hash starting with `$2a$`
- If the `.env` file leaks, the attacker cannot use the hash to log in without cracking it (which takes significant time at cost factor 12)
- `grep -r "ADMIN_PASSWORD=" backend/` returns no results (the old variable name is gone)
